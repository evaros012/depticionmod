EN:
It is forbidden to use in the APK modifications of the game Minecraft Bedrock!!! Violation entails administrative punishment.

Created by Marc Jones 
Supported version: Minecraft 1.11.0 (Bedrock Edition)
Database version: 1.8.0

RU:
Запрещено использование в APK модификациях игры Minecraft Bedrock!!! Нарушение влечёт за собой административное наказание.

Разработано Марком Джонсом
Поддерживаемая версия: Minecraft 1.11.0 (кроссплатформенное издание)
Версия системных данных: 1.8.0

©_marcjones_ 2018-2019 All rights reserved. Все права защищены.
Not affiliated with Mojang and Microsoft Studios.